import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import authHandler from './api/auth.js';
import bareHandler from './api/bare.js';
import healthHandler from './api/health.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.wasm': 'application/wasm',
};

function serveStaticFile(res, filePath, extraHeaders = {}) {
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stat.size,
      ...extraHeaders,
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const parsed = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const pathname = parsed.pathname;

    if (pathname === '/api/auth') {
      await authHandler(req, res);
      return;
    }

    if (pathname === '/api/health') {
      healthHandler(req, res);
      return;
    }

    if (
      pathname === '/api/bare' ||
      pathname === '/bare' ||
      pathname.startsWith('/bare/')
    ) {
      await bareHandler(req, res);
      return;
    }

    if (pathname.startsWith('/scramjet/') || pathname.startsWith('/service/')) {
      serveStaticFile(res, path.join(PUBLIC_DIR, 'sw-bootstrap.html'), {
        'Cache-Control': 'no-store',
      });
      return;
    }

    const relPath = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
    const safePath = path.normalize(path.join(PUBLIC_DIR, relPath));
    if (!safePath.startsWith(PUBLIC_DIR)) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }

    const extra =
      pathname === '/sw.js'
        ? {
            'Service-Worker-Allowed': '/',
            'Cache-Control': 'no-cache, no-store, must-revalidate',
          }
        : {};

    serveStaticFile(res, safePath, extra);
  } catch (err) {
    console.error('[XCP Server Error]', err);
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
    }
    res.end(JSON.stringify({ error: 'Internal Server Error' }));
  }
});

server.on('upgrade', (req, socket) => {
  socket.destroy();
});

server.listen(PORT, HOST, () => {
  console.log(`Xbox Cloud Gateway running at http://${HOST}:${PORT}`);
});
