# Xbox Cloud Gaming Gateway (Vercel Deployable — Locked to Xbox Cloud Only)

A dedicated browser gateway purpose-built **exclusively for Xbox Cloud Gaming (`xbox.com/play`)**, pre-configured for **Vercel Serverless (`iad1` — Washington, D.C. / US-East)** and protected by a cryptographic **Access PIN / Passcode Gate**.

All custom URL inputs, search bars, and external links are removed and **strictly blocked at both the server (`/api/bare`) and Service Worker levels** — this deployment can **only** access Xbox Cloud Gaming and official Microsoft Account sign-in.

---

## Default Access PIN (Change Before Sharing!)

- **Initial Default PIN:** `1170`
- **Recommended (Vercel Dashboard):** In your Vercel project, go to **Settings → Environment Variables** and add:
  - Name: `ACCESS_PIN`
  - Value: *your custom PIN or password* (supports digits or full passphrases)
  - Redeploy (or set it during initial import). Changing `ACCESS_PIN` immediately invalidates any older session cookies.
- **Alternative (Before Deploying):** Edit `"defaultPin"` in `config.json`.

---

## Quick Deploy to Vercel

### Option 1: Vercel CLI (Fastest directly from this `.zip`)
1. Extract `xbox-cloud-proxy-vercel.zip` into a folder.
2. Open a terminal inside that folder and run:
   ```bash
   npx vercel --prod
   ```
3. To set your custom PIN via CLI:
   ```bash
   npx vercel env add ACCESS_PIN production
   npx vercel --prod
   ```

### Option 2: GitHub + Vercel Dashboard (Recommended for Easy Updates)
1. Extract `xbox-cloud-proxy-vercel.zip`.
2. Upload the extracted files (`api/`, `lib/`, `public/`, `scripts/`, `config.json`, `package.json`, `server.js`, `vercel.json`) to a **Private GitHub Repository** *(do not upload `node_modules`)*.
3. Open [https://vercel.com/new](https://vercel.com/new) and **Import** your repository:
   - **Framework Preset:** `Other`
   - **Environment Variables:** Add `ACCESS_PIN` = `your-secret-passcode`
4. Click **Deploy**. Your `https://your-project.vercel.app` gateway will deploy in **`iad1` (US-East)**.

### Option 3: Run Locally or on Any Node Host
```bash
npm install
ACCESS_PIN=1170 npm start
```
Open `http://localhost:3000`.

---

## Security & Xbox-Only Enforcement

- **Strict Server-Side Allowlist (`lib/allowlist.js` + `api/bare.js`):** Every proxied request is validated on the server before forwarding. Only official Xbox Cloud Gaming, Xbox Live, Microsoft Account (`login.live.com` / `microsoftonline.com`), and Microsoft/Azure static asset domains are permitted; all other domains return `403 Forbidden`.
- **No URL Bars or Link Pickers:** Neither the launcher nor the in-stream HUD contains any URL input, search bar, or external shortcut.
- **HMAC-SHA256 PIN Gate:** Protects both the UI and `/bare/` transport with brute-force rate limiting so unauthorized visitors cannot use your Vercel bandwidth.
- **xCloud Enhancements:** Includes `EastUS` (`iad1`-matched) Azure blade selector, 1080p 60FPS High-Bitrate Unlock for Chromebooks/macOS/Linux/Android, HTML5 Gamepad + Pointer Lock passthrough, Screen Wake Lock, Video Clarity filter, and collapsible Stealth HUD.
