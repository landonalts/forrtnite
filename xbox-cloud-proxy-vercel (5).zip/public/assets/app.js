/* global BareMux, $scramjetLoadController, __uv$config */

const XBOX_CLOUD_HOME = 'https://play.xbox.com/';

const CLOAK_PRESETS = {
  none: {
    title: 'Xbox Cloud Gaming — US-East (iad1)',
    icon: '/assets/favicon.svg',
  },
  docs: {
    title: 'Untitled document - Google Docs',
    icon: 'https://ssl.gstatic.com/docs/documents/images/kix-favicon7.ico',
  },
  canvas: {
    title: 'Dashboard',
    icon: 'https://du11hjcvx0uqb.cloudfront.net/dist/images/favicon-e10d657a73.ico',
  },
  calc: {
    title: 'Scientific Calculator',
    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="%23334155"/><text x="16" y="22" font-size="18" text-anchor="middle" fill="white">∑</text></svg>',
  },
};

const PREFS_KEY = '__xcp_prefs_v2__';

const state = {
  authenticated: false,
  bareToken: null,
  vercelRegion: 'iad1',
  runtimeReady: false,
  runtimePromise: null,
  bareConnection: null,
  scramjet: null,
  scramFrame: null,
  iframeEl: null,
  activeEngine: null,
  hasActiveSession: false,
  wakeLock: null,
  capturedOAuthUrl: null,
  capturedRedirectUri: 'https://play.xbox.com/auth/msa',
  prefs: {
    engine: 'scramjet',
    region: 'EastUS',
    boost1080p: true,
    clarity: 'off',
    cloak: 'none',
  },
};

function loadSavedPrefs(serverDefaults = {}) {
  state.prefs.engine = serverDefaults.engine || 'scramjet';
  state.prefs.region = serverDefaults.xboxRegion || 'EastUS';
  state.prefs.boost1080p = serverDefaults.streamBoost1080p !== false;

  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      Object.assign(state.prefs, parsed);
    }
  } catch {
    // ignore storage errors
  }
}

function savePrefs() {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(state.prefs));
  } catch {
    // ignore storage errors
  }
}

function applyCloak(presetKey) {
  const preset = CLOAK_PRESETS[presetKey] || CLOAK_PRESETS.none;
  document.title = preset.title;
  const link = document.querySelector("link[rel='icon']");
  if (link) link.href = preset.icon;
}

async function ensureServiceWorkerReady() {
  if (!('serviceWorker' in navigator)) {
    throw new Error('Service Workers require HTTPS or localhost.');
  }

  await navigator.serviceWorker.register('/sw.js', { scope: '/' });
  await navigator.serviceWorker.ready;

  if (!navigator.serviceWorker.controller) {
    await new Promise((resolve) => {
      const done = () => resolve();
      navigator.serviceWorker.addEventListener('controllerchange', done, { once: true });
      setTimeout(done, 1500);
    });
  }
}

async function refreshBareTransport() {
  if (!state.bareConnection || !state.bareToken) return;
  const bareUrl = `${location.origin}/bare/`;
  await state.bareConnection.setTransport('/vendor/baremod/auth-transport.mjs?v=4', [
    bareUrl,
    state.bareToken,
    {
      streamBoost1080p: state.prefs.boost1080p,
      serverlessHttpOnly: true,
    },
  ]);
}

async function initProxyRuntime() {
  if (state.runtimeReady) return;
  if (state.runtimePromise) return state.runtimePromise;

  state.runtimePromise = (async () => {
    const swDot = document.getElementById('sw-dot');
    const swLabel = document.getElementById('sw-status-text');

    try {
      const { ScramjetController } = $scramjetLoadController();
      state.scramjet = new ScramjetController({
        prefix: '/scramjet/',
        files: {
          wasm: '/vendor/scram/scramjet.wasm.wasm',
          all: '/vendor/scram/scramjet.all.js',
          sync: '/vendor/scram/scramjet.sync.js',
        },
        flags: {
          serviceworkers: false,
          syncxhr: false,
          sourcemaps: false,
          scramitize: false,
          allowInvalidJs: true,
          allowFailedIntercepts: true,
        },
      });
      await state.scramjet.init();

      await ensureServiceWorkerReady();

      state.bareConnection = new BareMux.BareMuxConnection('/vendor/baremux/worker-entry.js?v=4');
      await refreshBareTransport();

      state.runtimeReady = true;
      if (swDot) swDot.className = 'dot ok';
      if (swLabel) swLabel.textContent = 'SW Ready';
    } catch (err) {
      console.error('[XCP] Runtime initialization failed:', err);
      if (swDot) swDot.className = 'dot warn';
      if (swLabel) swLabel.textContent = 'SW Error';
      state.runtimePromise = null;
      throw err;
    }
  })();

  return state.runtimePromise;
}

function decodeProxiedFrameLocation(rawHref = '') {
  if (!rawHref) return null;
  try {
    const u = new URL(rawHref, location.origin);
    if (u.pathname.startsWith('/scramjet/')) {
      const encoded = u.pathname.slice('/scramjet/'.length);
      return decodeURIComponent(encoded) + (u.hash || '');
    }
    if (u.pathname.startsWith('/service/')) {
      const encoded = u.pathname.slice('/service/'.length);
      return __uv$config.decodeUrl(encoded) + (u.hash || '');
    }
  } catch {
    return null;
  }
  return null;
}

function isXboxStreamingHost(hostname = '') {
  const h = String(hostname || '').toLowerCase();
  return (
    h === 'xbox.com' ||
    h.endsWith('.xbox.com') ||
    h.endsWith('.xboxlive.com') ||
    h.endsWith('.xboxservices.com') ||
    h.endsWith('.gamepass.com')
  );
}

function injectEnhancementsIntoWindow(win) {
  if (!win || win.__xcpBoostInstalled) return;
  try {
    win.__xcpBoostInstalled = true;

    // Evaluate target host dynamically inside getter:
    // - On xbox.com / xboxlive.com / gamepass.com -> Desktop Edge 131 (unlocks 1080p high bitrate)
    // - On login.live.com / account.live.com -> real browser UA (prevents MS fraud-telemetry mismatch!)
    if (/Chrome\/|Chromium\/|Edg\//.test(navigator.userAgent)) {
      const realUa = navigator.userAgent;
      try {
        Object.defineProperty(win.Navigator.prototype, 'userAgent', {
          get() {
            try {
              const rawHref = win.location?.href || '';
              const resolved = decodeProxiedFrameLocation(rawHref) || rawHref;
              const h = new URL(resolved).hostname.toLowerCase();
              if (state.prefs.boost1080p && isXboxStreamingHost(h)) {
                return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0';
              }
            } catch {
              // fall back to real UA
            }
            return realUa;
          },
          configurable: true,
        });
      } catch {
        // ignore
      }
    }

    const origFetch = win.fetch;
    if (typeof origFetch === 'function') {
      win.fetch = async function (...args) {
        const res = await origFetch.apply(this, args);
        try {
          const reqUrl =
            typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
          if (
            state.prefs.region &&
            state.prefs.region !== 'Auto' &&
            reqUrl.includes('.gssv-play-prod.xboxlive.com/v2/login/user')
          ) {
            const data = await res.clone().json();
            const regions = data?.offeringSettings?.regions;
            if (Array.isArray(regions) && regions.some((r) => r.name === state.prefs.region)) {
              data.offeringSettings.allowRegionSelection = true;
              for (const r of regions) {
                r.isDefault = r.name === state.prefs.region;
              }
              return new win.Response(JSON.stringify(data), {
                status: res.status,
                statusText: res.statusText,
                headers: res.headers,
              });
            }
          }
        } catch {
          // pass through untouched
        }
        return res;
      };
    }
  } catch {
    // cross-context guard
  }
}

function updateOAuthModalUi() {
  const statusEl = document.getElementById('oauth-capture-status');
  const openLink = document.getElementById('oauth-open-direct-link');
  const copyBtn = document.getElementById('oauth-copy-btn');

  if (state.capturedOAuthUrl) {
    if (statusEl) {
      statusEl.innerHTML =
        '✅ <strong>Xbox Sign-In link ready!</strong> Click <strong>1. Open Microsoft Sign-In (Real IP)</strong> below to sign in without Vercel’s server IP.';
    }
    if (openLink) {
      openLink.href = state.capturedOAuthUrl;
      openLink.classList.remove('disabled-link');
    }
    if (copyBtn) {
      copyBtn.disabled = false;
    }
  } else {
    if (statusEl) {
      statusEl.innerHTML =
        'Click <strong>↻ Generate Sign-In Link</strong> below (or click <strong>Sign in</strong> inside Xbox Cloud first) to prepare your secure Xbox OAuth session.';
    }
    if (openLink) {
      openLink.href = '#';
      openLink.classList.add('disabled-link');
    }
    if (copyBtn) {
      copyBtn.disabled = true;
    }
  }
}

function inspectActiveFrameUrl() {
  if (!state.iframeEl) return;
  const loginFixBtn = document.getElementById('hud-login-fix-btn');
  try {
    const rawHref = state.iframeEl.contentWindow?.location?.href || '';
    const decoded = decodeProxiedFrameLocation(rawHref);
    if (!decoded) return;

    const parsed = new URL(decoded);
    const host = parsed.hostname.toLowerCase();

    // Capture initial Xbox PKCE OAuth URL (contains code_challenge + state)
    if (
      (host === 'login.live.com' || host.endsWith('.microsoftonline.com')) &&
      parsed.searchParams.has('code_challenge') &&
      parsed.searchParams.has('state')
    ) {
      state.capturedOAuthUrl = decoded;
      const redir = parsed.searchParams.get('redirect_uri');
      if (redir && /^https:\/\/(play|www)\.xbox\.com\/auth\//i.test(redir)) {
        state.capturedRedirectUri = redir;
      }
      updateOAuthModalUi();
    }

    // Pulse the HUD Login Fix button whenever the user is on Microsoft Sign-In / Identity Check
    if (loginFixBtn) {
      const onMsAuth =
        host.endsWith('live.com') || host.endsWith('microsoftonline.com');
      loginFixBtn.classList.toggle('hud-btn-pulse', onMsAuth);
    }
  } catch {
    // ignore transient navigation states
  }
}

function parseStrictXboxOAuthCallback(rawInput = '') {
  const trimmed = String(rawInput || '').trim();
  if (!trimmed) {
    return { ok: false, error: 'Please paste the redirect URL from the Microsoft Sign-In tab.' };
  }

  // Case 1: Raw fragment pasted (#code=...&state=... or code=...&state=...)
  if (trimmed.startsWith('#code=') || trimmed.startsWith('code=')) {
    const hash = trimmed.startsWith('#') ? trimmed : `#${trimmed}`;
    const params = new URLSearchParams(hash.slice(1));
    if (!params.get('code') || !params.get('state')) {
      return { ok: false, error: 'Callback must include both code= and state= parameters.' };
    }
    return {
      ok: true,
      baseUrl: state.capturedRedirectUri || 'https://play.xbox.com/auth/msa',
      hash,
    };
  }

  // Case 2: Full Xbox OAuth callback URL pasted (strictly locked to *.xbox.com/auth/*)
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return {
      ok: false,
      error:
        'Invalid format. Copy the full play.xbox.com/auth/msa#code=... URL from the tab address bar after signing in.',
    };
  }

  const host = parsed.hostname.toLowerCase();
  const isXboxAuthHost =
    host === 'play.xbox.com' || host === 'www.xbox.com' || host === 'account.xbox.com';
  if (!isXboxAuthHost || !parsed.pathname.startsWith('/auth/')) {
    return {
      ok: false,
      error:
        'Locked to Xbox Cloud Gaming: only an official xbox.com/auth/msa#code=... OAuth callback is accepted.',
    };
  }

  const hashParams = new URLSearchParams((parsed.hash || '').replace(/^#/, ''));
  const queryParams = parsed.searchParams;

  const oauthErr = hashParams.get('error') || queryParams.get('error');
  if (oauthErr) {
    const desc =
      hashParams.get('error_description') ||
      queryParams.get('error_description') ||
      oauthErr;
    return { ok: false, error: `Microsoft returned an OAuth error: ${desc}` };
  }

  const hasCode = Boolean(hashParams.get('code') || queryParams.get('code'));
  if (!hasCode) {
    return {
      ok: false,
      error:
        'No authorization code found in that URL. Finish signing in on Microsoft until the tab redirects to play.xbox.com/auth/msa#code=...',
    };
  }

  const baseUrl = `${parsed.origin}${parsed.pathname}${parsed.search}`;
  return {
    ok: true,
    baseUrl,
    hash: parsed.hash || '',
  };
}

function applyClarityToActiveFrame() {
  const mode = state.prefs.clarity || 'off';
  let filterCss = 'none';
  if (mode === 'crisp') filterCss = 'contrast(1.05) saturate(1.08)';
  else if (mode === 'vivid') filterCss = 'contrast(1.08) saturate(1.16) brightness(1.02)';

  const btn = document.getElementById('hud-clarity-btn');
  if (btn) {
    btn.textContent =
      mode === 'off' ? 'Clarity: Off' : mode === 'crisp' ? 'Clarity: Crisp' : 'Clarity: Vivid';
  }

  if (!state.iframeEl) return;
  state.iframeEl.style.filter = filterCss;
}

async function acquireWakeLock() {
  if (!('wakeLock' in navigator)) return;
  try {
    if (!state.wakeLock) {
      state.wakeLock = await navigator.wakeLock.request('screen');
      state.wakeLock.addEventListener('release', () => {
        state.wakeLock = null;
      });
    }
  } catch {
    // ignore wake lock restrictions
  }
}

function createFreshIframe() {
  const host = document.getElementById('frame-host');
  if (state.iframeEl) {
    state.iframeEl.remove();
    state.iframeEl = null;
  }
  state.scramFrame = null;

  const iframe = document.createElement('iframe');
  iframe.id = 'proxy-frame';
  iframe.name = 'proxy-frame';
  iframe.className = 'proxy-iframe';
  iframe.setAttribute(
    'allow',
    'gamepad *; autoplay *; fullscreen *; pointer-lock *; clipboard-read; clipboard-write; encrypted-media'
  );
  iframe.setAttribute('allowfullscreen', 'true');

  const loader = document.getElementById('stream-loader');
  if (loader) loader.classList.remove('hidden');

  iframe.addEventListener('load', () => {
    if (loader) loader.classList.add('hidden');
    applyClarityToActiveFrame();
    inspectActiveFrameUrl();
    iframe.focus();
  });

  host.prepend(iframe);
  state.iframeEl = iframe;
  return iframe;
}

async function launchXboxCloud(forceNewFrame = false) {
  const streamLayer = document.getElementById('stream-layer');
  const hudEngineBtn = document.getElementById('hud-engine-btn');
  const resumeBtn = document.getElementById('resume-session-btn');
  const loader = document.getElementById('stream-loader');
  const loaderText = document.getElementById('loader-text');

  streamLayer.classList.remove('hidden');
  document.body.classList.add('streaming-active');
  if (loader) loader.classList.remove('hidden');
  if (loaderText) {
    loaderText.textContent = `Connecting to Xbox Cloud Gaming (${state.vercelRegion.toUpperCase()} • ${state.prefs.engine.toUpperCase()})...`;
  }

  await initProxyRuntime();
  await acquireWakeLock();

  const desiredEngine = state.prefs.engine;
  if (hudEngineBtn) {
    hudEngineBtn.textContent = desiredEngine === 'scramjet' ? 'Engine: Scramjet' : 'Engine: UV';
  }

  const needRebuild = forceNewFrame || !state.iframeEl || state.activeEngine !== desiredEngine;
  if (needRebuild) {
    const iframe = createFreshIframe();
    state.activeEngine = desiredEngine;

    if (desiredEngine === 'scramjet') {
      state.scramFrame = state.scramjet.createFrame(iframe);
      state.scramFrame.addEventListener('context', (e) => {
        if (e?.window) {
          injectEnhancementsIntoWindow(e.window);
        }
      });
    }
  }

  if (desiredEngine === 'scramjet' && state.scramFrame) {
    state.scramFrame.go(XBOX_CLOUD_HOME);
  } else if (state.iframeEl) {
    state.iframeEl.src = __uv$config.prefix + __uv$config.encodeUrl(XBOX_CLOUD_HOME);
  }

  state.hasActiveSession = true;
  if (resumeBtn) resumeBtn.removeAttribute('class'), (resumeBtn.className = 'btn-ghost');

  setTimeout(() => {
    if (loader) loader.classList.add('hidden');
  }, 7000);
}

function showDashboardKeepStream() {
  const streamLayer = document.getElementById('stream-layer');
  streamLayer.classList.add('hidden');
  document.body.classList.remove('streaming-active');
}

function resumeActiveStream() {
  if (!state.hasActiveSession) return;
  const streamLayer = document.getElementById('stream-layer');
  streamLayer.classList.remove('hidden');
  document.body.classList.add('streaming-active');
  state.iframeEl?.focus();
}

async function measurePing() {
  const pingText = document.getElementById('ping-status-text');
  const hudPing = document.getElementById('hud-ping-badge');
  const t0 = performance.now();
  try {
    const res = await fetch('/api/health', { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    const rtt = Math.max(1, Math.round(performance.now() - t0));
    state.vercelRegion = data.vercelRegion || 'iad1';
    const label = `${state.vercelRegion.toUpperCase()} • ${rtt}ms`;
    if (pingText) pingText.textContent = label;
    if (hudPing) hudPing.textContent = label;
  } catch {
    if (pingText) pingText.textContent = `${state.vercelRegion.toUpperCase()} • offline`;
  }
}

function monitorGamepads() {
  const padDot = document.getElementById('pad-dot');
  const padText = document.getElementById('pad-status-text');

  function updatePadStatus() {
    if (!navigator.getGamepads) return;
    const pads = Array.from(navigator.getGamepads()).filter(Boolean);
    if (pads.length > 0) {
      if (padDot) padDot.className = 'dot ok';
      const shortName = pads[0].id.split('(')[0].trim().slice(0, 24) || 'Gamepad';
      if (padText) padText.textContent = shortName;
    } else {
      if (padDot) padDot.className = 'dot';
      if (padText) padText.textContent = 'No Controller (KBM Ready)';
    }
  }

  window.addEventListener('gamepadconnected', updatePadStatus);
  window.addEventListener('gamepaddisconnected', updatePadStatus);
  setInterval(updatePadStatus, 2500);
  updatePadStatus();
}

function bindSettingsControls() {
  const engineSel = document.getElementById('pref-engine');
  const regionSel = document.getElementById('pref-region');
  const boostChk = document.getElementById('pref-boost1080p');
  const cloakSel = document.getElementById('pref-cloak');

  if (engineSel) {
    engineSel.value = state.prefs.engine;
    engineSel.addEventListener('change', () => {
      state.prefs.engine = engineSel.value;
      savePrefs();
    });
  }

  if (regionSel) {
    regionSel.value = state.prefs.region;
    regionSel.addEventListener('change', () => {
      state.prefs.region = regionSel.value;
      savePrefs();
      applyClarityToActiveFrame();
    });
  }

  if (boostChk) {
    boostChk.checked = Boolean(state.prefs.boost1080p);
    boostChk.addEventListener('change', async () => {
      state.prefs.boost1080p = boostChk.checked;
      savePrefs();
      await refreshBareTransport();
      applyClarityToActiveFrame();
    });
  }

  if (cloakSel) {
    cloakSel.value = state.prefs.cloak || 'none';
    applyCloak(state.prefs.cloak);
    cloakSel.addEventListener('change', () => {
      state.prefs.cloak = cloakSel.value;
      savePrefs();
      applyCloak(state.prefs.cloak);
    });
  }
}

function bindLoginFixModal() {
  const modal = document.getElementById('login-fix-modal');
  const openBtn = document.getElementById('hud-login-fix-btn');
  const closeBtn = document.getElementById('login-fix-close-btn');
  const generateBtn = document.getElementById('oauth-generate-btn');
  const openDirectLink = document.getElementById('oauth-open-direct-link');
  const copyBtn = document.getElementById('oauth-copy-btn');
  const form = document.getElementById('oauth-callback-form');
  const input = document.getElementById('oauth-callback-input');
  const errBox = document.getElementById('oauth-callback-error');

  openBtn?.addEventListener('click', () => {
    inspectActiveFrameUrl();
    updateOAuthModalUi();
    errBox?.classList.add('hidden');
    modal?.classList.remove('hidden');
  });

  closeBtn?.addEventListener('click', () => {
    modal?.classList.add('hidden');
    state.iframeEl?.focus();
  });

  modal?.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.add('hidden');
      state.iframeEl?.focus();
    }
  });

  openDirectLink?.addEventListener('click', (e) => {
    if (!state.capturedOAuthUrl) {
      e.preventDefault();
    }
  });

  generateBtn?.addEventListener('click', () => {
    try {
      const doc = state.iframeEl?.contentDocument;
      if (doc) {
        const candidates = [...doc.querySelectorAll('a, button')];
        const signBtn = candidates.find(
          (el) =>
            /^sign in$/i.test((el.textContent || '').trim()) &&
            el.getBoundingClientRect().width > 0
        );
        if (signBtn) {
          signBtn.click();
          const statusEl = document.getElementById('oauth-capture-status');
          if (statusEl) {
            statusEl.innerHTML = '⏳ Generating Xbox Sign-In session... (takes ~3 seconds)';
          }
          return;
        }
      }
      // If already off home page, reload Xbox home so user can click Sign in fresh
      if (state.activeEngine === 'scramjet' && state.scramFrame) {
        state.scramFrame.go(XBOX_CLOUD_HOME);
      } else if (state.iframeEl) {
        state.iframeEl.src = __uv$config.prefix + __uv$config.encodeUrl(XBOX_CLOUD_HOME);
      }
    } catch {
      // ignore
    }
  });

  copyBtn?.addEventListener('click', async () => {
    if (!state.capturedOAuthUrl) return;
    try {
      await navigator.clipboard.writeText(state.capturedOAuthUrl);
      const orig = copyBtn.textContent;
      copyBtn.textContent = 'Copied!';
      setTimeout(() => {
        copyBtn.textContent = orig;
      }, 1800);
    } catch {
      // ignore
    }
  });

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    if (errBox) errBox.classList.add('hidden');

    const parsed = parseStrictXboxOAuthCallback(input?.value || '');
    if (!parsed.ok) {
      if (errBox) {
        errBox.textContent = parsed.error;
        errBox.classList.remove('hidden');
      }
      return;
    }

    if (!state.iframeEl) return;

    const loader = document.getElementById('stream-loader');
    const loaderText = document.getElementById('loader-text');
    if (loader) loader.classList.remove('hidden');
    if (loaderText) loaderText.textContent = 'Completing Xbox Cloud Sign-In...';

    if (state.activeEngine === 'scramjet') {
      state.iframeEl.src =
        '/scramjet/' + encodeURIComponent(parsed.baseUrl) + parsed.hash;
    } else {
      state.iframeEl.src =
        __uv$config.prefix + __uv$config.encodeUrl(parsed.baseUrl) + parsed.hash;
    }

    if (input) input.value = '';
    modal?.classList.add('hidden');
    setTimeout(() => {
      if (loader) loader.classList.add('hidden');
    }, 6000);
  });
}

function bindHudAndPortalActions() {
  document.getElementById('launch-main-btn')?.addEventListener('click', () => {
    launchXboxCloud();
  });

  document.getElementById('resume-session-btn')?.addEventListener('click', () => {
    resumeActiveStream();
  });

  document.getElementById('clear-cookies-btn')?.addEventListener('click', async () => {
    if (!confirm('Clear proxied Xbox/Microsoft cookies and cached state in this browser?')) {
      return;
    }
    try {
      if (indexedDB.databases) {
        const dbs = await indexedDB.databases();
        for (const db of dbs) {
          if (db.name) indexedDB.deleteDatabase(db.name);
        }
      }
      state.runtimeReady = false;
      state.runtimePromise = null;
      await initProxyRuntime();
      alert('Proxied Xbox cookies cleared.');
    } catch (err) {
      console.error(err);
    }
  });

  const lockHandler = async () => {
    await fetch('/api/auth', { method: 'DELETE' });
    location.reload();
  };
  document.getElementById('lock-portal-btn')?.addEventListener('click', lockHandler);
  document.getElementById('hud-lock-btn')?.addEventListener('click', lockHandler);

  document.getElementById('hud-home-btn')?.addEventListener('click', () => {
    showDashboardKeepStream();
  });

  document.getElementById('hud-back-btn')?.addEventListener('click', () => {
    if (state.activeEngine === 'scramjet' && state.scramFrame) state.scramFrame.back();
    else state.iframeEl?.contentWindow?.history.back();
  });

  document.getElementById('hud-reload-btn')?.addEventListener('click', () => {
    if (state.activeEngine === 'scramjet' && state.scramFrame) state.scramFrame.reload();
    else state.iframeEl?.contentWindow?.location.reload();
  });

  document.getElementById('hud-engine-btn')?.addEventListener('click', () => {
    state.prefs.engine = state.prefs.engine === 'scramjet' ? 'uv' : 'scramjet';
    const engineSel = document.getElementById('pref-engine');
    if (engineSel) engineSel.value = state.prefs.engine;
    savePrefs();
    launchXboxCloud(true);
  });

  document.getElementById('hud-clarity-btn')?.addEventListener('click', () => {
    const order = ['off', 'crisp', 'vivid'];
    const idx = order.indexOf(state.prefs.clarity || 'off');
    state.prefs.clarity = order[(idx + 1) % order.length];
    savePrefs();
    applyClarityToActiveFrame();
  });

  document.getElementById('hud-fullscreen-btn')?.addEventListener('click', () => {
    const layer = document.getElementById('stream-layer');
    if (!document.fullscreenElement) {
      layer?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  });

  const hudBar = document.getElementById('stream-hud');
  const restorePill = document.getElementById('hud-restore-pill');
  document.getElementById('hud-hide-btn')?.addEventListener('click', () => {
    hudBar?.classList.add('hidden');
    restorePill?.classList.remove('hidden');
    state.iframeEl?.focus();
  });
  restorePill?.addEventListener('click', () => {
    restorePill.classList.add('hidden');
    hudBar?.classList.remove('hidden');
  });

  bindLoginFixModal();
  setInterval(inspectActiveFrameUrl, 600);
}

async function enterPortal(authData) {
  state.authenticated = true;
  state.bareToken = authData.bareToken;
  state.vercelRegion = authData.vercelRegion || 'iad1';

  loadSavedPrefs(authData.defaults || {});

  document.getElementById('auth-screen')?.classList.add('hidden');
  document.getElementById('portal-shell')?.classList.remove('hidden');

  bindSettingsControls();
  bindHudAndPortalActions();
  monitorGamepads();
  measurePing();
  setInterval(measurePing, 15000);

  initProxyRuntime().catch(() => {});
}

async function bootstrap() {
  const authForm = document.getElementById('auth-form');
  const pinInput = document.getElementById('pin-input');
  const authError = document.getElementById('auth-error');
  const authBtn = document.getElementById('auth-submit-btn');
  const pinSetupNote = document.getElementById('pin-setup-note');

  try {
    const res = await fetch('/api/auth', { cache: 'no-store' });
    const data = await res.json();
    if (data.authenticated && data.bareToken) {
      await enterPortal(data);
      return;
    }
    if (pinSetupNote && !data.usingCustomEnvPin) {
      pinSetupNote.innerHTML =
        'Protected by access passcode. Set <code>ACCESS_PIN</code> in Vercel Environment Variables to customize your private PIN (see <code>README.md</code> for initial default).';
    }
  } catch (err) {
    console.error('[XCP] Auth check error:', err);
  }

  document.getElementById('auth-screen')?.classList.remove('hidden');
  pinInput?.focus();

  authForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (authError) authError.classList.add('hidden');
    if (authBtn) {
      authBtn.disabled = true;
      authBtn.textContent = 'Verifying...';
    }

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: pinInput?.value || '' }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        if (authError) {
          authError.textContent = data.error || 'Access denied.';
          authError.classList.remove('hidden');
        }
        pinInput?.select();
        return;
      }
      await enterPortal(data);
    } catch {
      if (authError) {
        authError.textContent = 'Network error verifying passcode.';
        authError.classList.remove('hidden');
      }
    } finally {
      if (authBtn) {
        authBtn.disabled = false;
        authBtn.textContent = 'Unlock Xbox Cloud';
      }
    }
  });
}

bootstrap();
