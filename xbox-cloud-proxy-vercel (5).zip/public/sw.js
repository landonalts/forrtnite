/* global UVServiceWorker, $scramjetLoadWorker, __uv$config */
/* XCP ServiceWorker v1.4.0 */
(function ensureScramjetStoresAndPsl() {
  try {
    const req = indexedDB.open('$scramjet', 1);
    req.onupgradeneeded = (ev) => {
      const db = ev.target.result;
      for (const name of [
        'config',
        'cookies',
        'redirectTrackers',
        'referrerPolicies',
        'publicSuffixList',
      ]) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name);
        }
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      try {
        const tx = db.transaction('publicSuffixList', 'readwrite');
        const store = tx.objectStore('publicSuffixList');
        const getReq = store.get('publicSuffixList');
        getReq.onsuccess = () => {
          if (!getReq.result || Date.now() >= (getReq.result.expiry || 0)) {
            store.put(
              {
                data: [
                  'com',
                  'net',
                  'org',
                  'ms',
                  'microsoft',
                  'co.uk',
                  'org.uk',
                  'com.au',
                  'com.br',
                  'co.jp',
                  'co.kr',
                  'com.mx',
                  'com.cn',
                  'azureedge.net',
                  'azurefd.net',
                  'azurewebsites.net',
                  'akamaized.net',
                  'trafficmanager.net',
                ],
                expiry: Date.now() + 7 * 24 * 60 * 60 * 1000,
              },
              'publicSuffixList'
            );
          }
        };
        tx.oncomplete = () => db.close();
        tx.onerror = () => db.close();
      } catch {
        db.close();
      }
    };
  } catch {
    // ignore
  }
})();

importScripts('/vendor/uv/uv.bundle.js');
importScripts('/vendor/uv/uv.config.js');
importScripts('/vendor/uv/uv.sw.js');
importScripts('/vendor/scram/scramjet.all.js');

const ALLOWED_XBOX_DOMAINS = [
  'xbox.com',
  'xboxlive.com',
  'xboxservices.com',
  'gamepass.com',
  'xboxab.com',
  'playfabapi.com',
  'abminfra.net',
  'live.com',
  'live.net',
  'microsoft.com',
  'microsoft',
  'microsoftonline.com',
  'microsoftonline-p.com',
  'msauth.net',
  'msftauth.net',
  'msauthimages.net',
  'msftauthimages.net',
  'msidentity.com',
  'passport.net',
  'office.com',
  'office.net',
  'msn.com',
  's-microsoft.com',
  'onestore.ms',
  'msecnd.net',
  'windows.net',
  'azureedge.net',
  'azurefd.net',
  'azurewebsites.net',
  'azure.com',
  'trafficmanager.net',
  'akamaized.net',
  'scene7.com',
  'king.com',
  'cdnjs.cloudflare.com',
  'gfx.ms',
  'sfx.ms',
  'aka.ms',
  'arkoselabs.com',
  'funcaptcha.com',
];

function isAllowedHost(hostname = '') {
  const h = String(hostname || '').trim().toLowerCase().replace(/\.$/, '');
  if (!h) return false;
  for (const d of ALLOWED_XBOX_DOMAINS) {
    if (h === d || h.endsWith('.' + d)) return true;
  }
  return false;
}

function decodeProxiedTargetUrl(reqUrl) {
  const origin = self.location.origin;
  try {
    if (reqUrl.startsWith(origin + '/scramjet/')) {
      const encoded = reqUrl.slice((origin + '/scramjet/').length).split('#')[0];
      return decodeURIComponent(encoded);
    }
    if (reqUrl.startsWith(origin + '/service/')) {
      const encoded = reqUrl.slice((origin + '/service/').length).split('#')[0];
      return __uv$config.decodeUrl(encoded);
    }
  } catch {
    return null;
  }
  return null;
}

function renderBlockedPage(returnPath) {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Locked to Xbox Cloud Gaming</title>
  <style>
    body {
      margin: 0;
      min-height: 100vh;
      display: grid;
      place-items: center;
      background: #090c0a;
      color: #f1f7f2;
      font-family: 'Segoe UI', system-ui, sans-serif;
    }
    .card {
      max-width: 420px;
      padding: 2rem;
      text-align: center;
      background: #111613;
      border: 1px solid rgba(22, 198, 12, 0.35);
      border-radius: 16px;
    }
    h2 { margin: 0 0 0.65rem; font-size: 1.25rem; }
    p { margin: 0 0 1.35rem; color: #9fb0a3; font-size: 0.9rem; line-height: 1.5; }
    a {
      display: inline-block;
      padding: 0.72rem 1.25rem;
      border-radius: 10px;
      background: #107c10;
      color: #fff;
      text-decoration: none;
      font-weight: 600;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <div class="card">
    <h2>Xbox Cloud Gaming Only</h2>
    <p>This gateway is locked exclusively to Xbox Cloud Gaming. External links and other websites are disabled.</p>
    <a href="${returnPath}">Return to Xbox Cloud Gaming</a>
  </div>
</body>
</html>`;
  return new Response(html, {
    status: 403,
    headers: { 'Content-Type': 'text/html; charset=utf-8' },
  });
}

const uv = new UVServiceWorker();

self.addEventListener(
  'message',
  (event) => {
    if (event.data && event.data.scramjet$type === 'loadConfig') {
      event.stopImmediatePropagation();
      if (typeof scramjet !== 'undefined') {
        scramjet.config = undefined;
        scramjet.loadConfig().catch(() => {});
      }
    }
  },
  true
);

const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

async function handleProxiedFetch(event) {
  try {
    const reqUrl = event.request.url;
    const origin = self.location.origin;

    // Rescue relative ES module / CSS subresources under /scramjet/<relPath> using the proxied referrer URL
    if (reqUrl.startsWith(origin + '/scramjet/')) {
      const rawRest = reqUrl.slice((origin + '/scramjet/').length);
      let decodedCandidate = '';
      try {
        decodedCandidate = decodeURIComponent(rawRest.split('#')[0]);
      } catch {
        decodedCandidate = rawRest;
      }
      if (
        decodedCandidate &&
        !/^https?:\/\//i.test(decodedCandidate) &&
        !decodedCandidate.startsWith('$')
      ) {
        const refTarget = event.request.referrer
          ? decodeProxiedTargetUrl(event.request.referrer)
          : null;
        let baseForRelative = refTarget || 'https://play.xbox.com/assets/';
        if (
          baseForRelative === 'https://play.xbox.com/' &&
          /\.(m?js|css|wasm|woff2?|svg|png|webp)(\?|$)/i.test(decodedCandidate) &&
          !decodedCandidate.startsWith('assets/')
        ) {
          baseForRelative = 'https://play.xbox.com/assets/';
        }
        const resolvedTarget = new URL(decodedCandidate, baseForRelative).toString();
        if (isAllowedHost(new URL(resolvedTarget).hostname)) {
          return Response.redirect(
            origin + '/scramjet/' + encodeURIComponent(resolvedTarget),
            302
          );
        }
      }
    }

    const decodedUrl = decodeProxiedTargetUrl(reqUrl);
    if (decodedUrl && /^https?:\/\//i.test(decodedUrl)) {
      const targetHost = new URL(decodedUrl).hostname;
      if (!isAllowedHost(targetHost)) {
        const dest = event.request.destination;
        if (dest === 'document' || dest === 'iframe') {
          const isUv = event.request.url.includes('/service/');
          const xboxHome = 'https://www.xbox.com/en-US/play';
          const returnPath = isUv
            ? '/service/' + __uv$config.encodeUrl(xboxHome)
            : '/scramjet/' + encodeURIComponent(xboxHome);
          return renderBlockedPage(returnPath);
        }
        return new Response(null, { status: 204 });
      }
    }

    await scramjet.loadConfig();
    if (scramjet.route(event)) {
      return await scramjet.fetch(event);
    }
    if (uv.route(event)) {
      return await uv.fetch(event);
    }
  } catch (err) {
    console.error('[XCP ServiceWorker] Proxy route error:', err);
  }
  return fetch(event.request);
}

self.addEventListener('fetch', (event) => {
  const url = event.request.url;
  const origin = self.location.origin;

  if (
    url.startsWith(origin + '/api/') ||
    url.startsWith(origin + '/bare/') ||
    url === origin + '/' ||
    url === origin + '/index.html' ||
    url === origin + '/sw.js' ||
    url === origin + '/sw-bootstrap.html'
  ) {
    return;
  }

  event.respondWith(handleProxiedFetch(event));
});
