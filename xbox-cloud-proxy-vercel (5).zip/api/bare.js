import http from 'node:http';
import https from 'node:https';
import { isRequestAuthorized } from '../lib/security.js';
import { isAllowedXboxUrl } from '../lib/allowlist.js';

export const config = {
  api: {
    bodyParser: false,
    externalResolver: true,
  },
};

const MAX_HEADER_VALUE = 3072;
const NULL_BODY_STATUS = new Set([101, 204, 205, 304]);
const FORBIDDEN_SEND_HEADERS = new Set([
  'connection',
  'content-length',
  'transfer-encoding',
  'keep-alive',
  'upgrade',
]);
const FORBIDDEN_FORWARD_HEADERS = new Set([
  'connection',
  'transfer-encoding',
  'host',
  'origin',
  'referer',
]);
const FORBIDDEN_PASS_HEADERS = new Set([
  'vary',
  'connection',
  'transfer-encoding',
  'access-control-allow-headers',
  'access-control-allow-methods',
  'access-control-expose-headers',
  'access-control-max-age',
  'access-control-request-headers',
  'access-control-request-method',
]);

// play.xbox.com returns a 15-byte placeholder ("<!doctype html>") if Chromium sends
// Sec-CH-UA without these Critical-CH client hints, and Service Worker responses cannot
// complete Chromium's network-layer Critical-CH retry handshake. Supplying defaults
// guarantees play.xbox.com always serves the full SSR HTML on the first request.
const XBOX_CRITICAL_CLIENT_HINTS = {
  'sec-ch-prefers-color-scheme': 'dark',
  'sec-ch-forced-colors': 'none',
  'sec-ch-prefers-contrast': 'no-preference',
  'sec-ch-prefers-reduced-transparency': 'no-preference',
  'sec-ch-prefers-reduced-motion': 'no-preference',
  'sec-ch-viewport-width': '1920',
  'sec-ch-viewport-height': '1080',
};

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 128 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 128 });

export function normalizeBareUrl(rawUrl = '/') {
  const parsed = new URL(rawUrl, 'http://localhost');

  if (parsed.pathname === '/bare') {
    return '/bare/' + parsed.search;
  }
  if (parsed.pathname.startsWith('/bare/')) {
    let sub = parsed.pathname.slice('/bare'.length);
    if (sub === '/v1' || sub === '/v2' || sub === '/v3') {
      sub += '/';
    }
    return '/bare' + sub + parsed.search;
  }

  let bpath = parsed.searchParams.get('__bpath') || '/';
  parsed.searchParams.delete('__bpath');

  if (!bpath.startsWith('/')) {
    bpath = '/' + bpath;
  }
  if (bpath === '/v1' || bpath === '/v2' || bpath === '/v3') {
    bpath += '/';
  }

  const qs = parsed.searchParams.toString();
  return '/bare' + bpath + (qs ? '?' + qs : '');
}

function joinIncomingBareHeaders(reqHeaders) {
  const out = Object.create(null);
  for (const [k, v] of Object.entries(reqHeaders)) {
    if (v !== undefined) {
      out[k.toLowerCase()] = Array.isArray(v) ? v.join(', ') : String(v);
    }
  }

  if ('x-bare-headers-0' in out) {
    const parts = [];
    for (const key of Object.keys(out)) {
      if (key.startsWith('x-bare-headers-')) {
        const idx = parseInt(key.slice('x-bare-headers-'.length), 10);
        const val = out[key];
        if (!Number.isNaN(idx) && typeof val === 'string') {
          parts[idx] = val.startsWith(';') ? val.slice(1) : val;
        }
        delete out[key];
      }
    }
    out['x-bare-headers'] = parts.join('');
  }
  return out;
}

function splitOutgoingBareHeaders(headersObj, bareHeadersJson) {
  if (bareHeadersJson.length <= MAX_HEADER_VALUE) {
    headersObj['x-bare-headers'] = bareHeadersJson;
    return;
  }
  let idx = 0;
  for (let i = 0; i < bareHeadersJson.length; i += MAX_HEADER_VALUE) {
    headersObj[`x-bare-headers-${idx++}`] = `;${bareHeadersJson.slice(i, i + MAX_HEADER_VALUE)}`;
  }
}

function rawHeadersToObject(rawHeaders = []) {
  const result = Object.create(null);
  const lowerToOriginal = Object.create(null);

  for (let i = 0; i < rawHeaders.length; i += 2) {
    const name = rawHeaders[i];
    const value = rawHeaders[i + 1];
    const lower = name.toLowerCase();
    // Strip Critical-CH / Accept-CH so Chromium does not stall or loop on SW responses
    if (lower === 'critical-ch' || lower === 'accept-ch') {
      continue;
    }
    const canonical = lowerToOriginal[lower] || name;
    lowerToOriginal[lower] = canonical;

    if (lower === 'set-cookie') {
      if (!Array.isArray(result[canonical])) {
        result[canonical] = result[canonical] ? [result[canonical]] : [];
      }
      result[canonical].push(value);
    } else if (canonical in result) {
      result[canonical] = `${result[canonical]}, ${value}`;
    } else {
      result[canonical] = value;
    }
  }
  return result;
}

async function readRawRequestBody(req) {
  const method = (req.method || 'GET').toUpperCase();
  if (method === 'GET' || method === 'HEAD') {
    return null;
  }

  // Handle Vercel @vercel/node pre-parsed req.body safely without losing bytes
  const descriptor = Object.getOwnPropertyDescriptor(req, 'body');
  const hasEagerBody =
    (descriptor && 'value' in descriptor && descriptor.value !== undefined) ||
    (req.readableEnded && req.body !== undefined);

  if (hasEagerBody && req.body !== null && req.body !== undefined) {
    if (Buffer.isBuffer(req.body)) return req.body;
    if (req.body instanceof Uint8Array) return Buffer.from(req.body);
    if (typeof req.body === 'string') return Buffer.from(req.body, 'utf8');
    if (typeof req.body === 'object') {
      const ct = String(req.headers['content-type'] || '').toLowerCase();
      if (ct.includes('application/x-www-form-urlencoded')) {
        return Buffer.from(new URLSearchParams(req.body).toString(), 'utf8');
      }
      return Buffer.from(JSON.stringify(req.body), 'utf8');
    }
  }

  if (req.readableEnded) {
    return Buffer.alloc(0);
  }

  const chunks = [];
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}

function sendJson(res, status, data) {
  const payload = Buffer.from(JSON.stringify(data), 'utf8');
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': String(payload.byteLength),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Expose-Headers': '*',
    'Cache-Control': 'no-store',
  });
  res.end(payload);
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Expose-Headers': '*',
      'Access-Control-Max-Age': '7200',
    });
    res.end();
    return;
  }

  if (!isRequestAuthorized(req)) {
    return sendJson(res, 401, {
      code: 'UNAUTHORIZED',
      id: 'error.Unauthorized',
      message: 'Valid proxy PIN session required.',
    });
  }

  const normalizedUrl = normalizeBareUrl(req.url);
  const parsedRoute = new URL(normalizedUrl, 'http://localhost');

  // Bare metadata endpoint: GET /bare/
  if (parsedRoute.pathname === '/bare/') {
    return sendJson(res, 200, {
      versions: ['v3'],
      language: 'NodeJS',
      memoryUsage: Math.round((process.memoryUsage().heapUsed / 1024 / 1024) * 100) / 100,
      project: {
        name: 'xbox-cloud-bare-vercel',
        description: 'Vercel-native Bare v3 transport locked to Xbox Cloud Gaming',
        version: '1.3.0',
      },
    });
  }

  if (parsedRoute.pathname !== '/bare/v3/') {
    return sendJson(res, 404, {
      code: 'NOT_FOUND',
      id: 'error.NotFound',
      message: `Unsupported Bare route: ${parsedRoute.pathname}`,
    });
  }

  const joined = joinIncomingBareHeaders(req.headers);
  const xBareUrl = joined['x-bare-url'];
  if (!xBareUrl) {
    return sendJson(res, 400, {
      code: 'MISSING_BARE_HEADER',
      id: 'request.headers.x-bare-url',
      message: 'Missing x-bare-url header.',
    });
  }

  if (!isAllowedXboxUrl(xBareUrl)) {
    return sendJson(res, 403, {
      code: 'FORBIDDEN_HOST',
      id: 'error.ForbiddenHost',
      message: 'Locked exclusively to Xbox Cloud Gaming and Microsoft Sign-In.',
    });
  }

  let remoteUrl;
  try {
    remoteUrl = new URL(xBareUrl);
  } catch {
    return sendJson(res, 400, {
      code: 'INVALID_BARE_URL',
      id: 'request.headers.x-bare-url',
      message: 'Invalid x-bare-url.',
    });
  }

  let clientBareHeaders = {};
  if (joined['x-bare-headers']) {
    try {
      clientBareHeaders = JSON.parse(joined['x-bare-headers']);
    } catch (err) {
      return sendJson(res, 400, {
        code: 'INVALID_BARE_HEADER',
        id: 'request.headers.x-bare-headers',
        message: `Invalid JSON in x-bare-headers: ${err.message}`,
      });
    }
  }

  const hasCacheParam = parsedRoute.searchParams.has('cache');
  const forwardHeaders = ['accept-encoding', 'accept-language'];
  const passHeaders = ['content-encoding', 'content-length', 'last-modified'];
  const passStatus = [];

  if (hasCacheParam) {
    forwardHeaders.push('if-modified-since', 'if-none-match', 'cache-control');
    passHeaders.push('cache-control', 'etag');
    passStatus.push(304);
  }

  if (joined['x-bare-forward-headers']) {
    for (const h of joined['x-bare-forward-headers'].split(/,\s*/g)) {
      const lower = h.trim().toLowerCase();
      if (lower && !FORBIDDEN_FORWARD_HEADERS.has(lower)) {
        forwardHeaders.push(lower);
      }
    }
  }

  if (joined['x-bare-pass-headers']) {
    for (const h of joined['x-bare-pass-headers'].split(/,\s*/g)) {
      const lower = h.trim().toLowerCase();
      if (lower && !FORBIDDEN_PASS_HEADERS.has(lower)) {
        passHeaders.push(lower);
      }
    }
  }

  if (joined['x-bare-pass-status']) {
    for (const s of joined['x-bare-pass-status'].split(/,\s*/g)) {
      const code = parseInt(s, 10);
      if (!Number.isNaN(code)) passStatus.push(code);
    }
  }

  const sendHeaders = Object.create(null);
  const existingLowerKeys = new Set();
  for (const [k, v] of Object.entries(clientBareHeaders)) {
    const lower = k.toLowerCase();
    if (FORBIDDEN_SEND_HEADERS.has(lower)) continue;
    if (typeof v === 'string' || Array.isArray(v)) {
      sendHeaders[k] = v;
      existingLowerKeys.add(lower);
    }
  }

  for (const h of forwardHeaders) {
    if (joined[h] !== undefined && !existingLowerKeys.has(h.toLowerCase())) {
      sendHeaders[h] = joined[h];
      existingLowerKeys.add(h.toLowerCase());
    }
  }

  // Ensure play.xbox.com receives high-entropy Client Hints so it serves full HTML instead of the 15-byte placeholder
  const rHost = remoteUrl.hostname.toLowerCase();
  if (rHost === 'xbox.com' || rHost.endsWith('.xbox.com')) {
    for (const [chKey, chVal] of Object.entries(XBOX_CRITICAL_CLIENT_HINTS)) {
      if (!existingLowerKeys.has(chKey)) {
        sendHeaders[chKey] = chVal;
        existingLowerKeys.add(chKey);
      }
    }
  }

  // Ensure exact Host header
  let hasHost = false;
  for (const k of Object.keys(sendHeaders)) {
    if (k.toLowerCase() === 'host') {
      sendHeaders[k] = remoteUrl.host;
      hasHost = true;
    }
  }
  if (!hasHost) {
    sendHeaders.Host = remoteUrl.host;
  }

  const method = (req.method || 'GET').toUpperCase();
  let bodyBuffer = null;
  if (method !== 'GET' && method !== 'HEAD') {
    bodyBuffer = await readRawRequestBody(req);
    sendHeaders['Content-Length'] = String(bodyBuffer ? bodyBuffer.byteLength : 0);
  }

  const requestFn = remoteUrl.protocol === 'https:' ? https.request : http.request;
  const agent = remoteUrl.protocol === 'https:' ? httpsAgent : httpAgent;

  await new Promise((resolve) => {
    let finished = false;
    const done = () => {
      if (!finished) {
        finished = true;
        resolve();
      }
    };

    const upstreamReq = requestFn(
      remoteUrl,
      {
        method,
        headers: sendHeaders,
        agent,
        setHost: false,
        timeout: 45_000,
      },
      (upstreamRes) => {
        const upstreamStatus = upstreamRes.statusCode || 200;
        const outStatus = passStatus.includes(upstreamStatus) ? upstreamStatus : 200;

        const outHeaders = {
          'x-robots-tag': 'noindex',
          'access-control-allow-origin': '*',
          'access-control-allow-headers': '*',
          'access-control-allow-methods': '*',
          'access-control-expose-headers': '*',
          'access-control-max-age': '7200',
        };

        for (const h of passHeaders) {
          const val = upstreamRes.headers[h.toLowerCase()];
          if (val !== undefined) {
            outHeaders[h.toLowerCase()] = Array.isArray(val) ? val.join(', ') : String(val);
          }
        }

        if (outStatus !== 304) {
          outHeaders['x-bare-status'] = String(upstreamStatus);
          outHeaders['x-bare-status-text'] = upstreamRes.statusMessage || '';
          const mappedRaw = rawHeadersToObject(upstreamRes.rawHeaders);
          splitOutgoingBareHeaders(outHeaders, JSON.stringify(mappedRaw));
        }

        res.writeHead(outStatus, outHeaders);

        if (NULL_BODY_STATUS.has(outStatus) || method === 'HEAD') {
          upstreamRes.resume();
          res.end();
          done();
          return;
        }

        res.once('finish', done);
        res.once('close', () => {
          upstreamRes.destroy();
          done();
        });

        upstreamRes.on('error', () => {
          if (!res.writableEnded) res.end();
          done();
        });

        upstreamRes.pipe(res);
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy(new Error('Upstream request timed out'));
    });

    upstreamReq.on('error', (err) => {
      if (!res.headersSent) {
        sendJson(res, 500, {
          code: 'UPSTREAM_ERROR',
          id: 'response',
          message: err?.message || 'Upstream connection error',
        });
      } else if (!res.writableEnded) {
        res.end();
      }
      done();
    });

    if (bodyBuffer && bodyBuffer.byteLength > 0) {
      upstreamReq.end(bodyBuffer);
    } else {
      upstreamReq.end();
    }
  });
}
