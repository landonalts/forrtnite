export default function handler(req, res) {
  const payload = JSON.stringify({
    ok: true,
    service: 'xbox-cloud-proxy',
    vercelRegion: process.env.VERCEL_REGION || 'iad1',
    configuredRegion: 'iad1',
    timestamp: Date.now(),
  });
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(payload);
}
