import {
  buildSessionCookie,
  checkLoginRateLimit,
  clearFailedLogin,
  createAuthToken,
  extractRequestToken,
  getAppConfig,
  getClientIp,
  isUsingCustomEnvPin,
  recordFailedLogin,
  verifyAuthToken,
  verifyPinConstantTime,
} from '../lib/security.js';

async function readJsonBody(req) {
  if (req.body && typeof req.body === 'object') {
    return req.body;
  }
  if (typeof req.body === 'string' && req.body.length > 0) {
    return JSON.parse(req.body);
  }
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > 16_384) throw new Error('Payload too large');
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function sendJson(res, status, data, extraHeaders = {}) {
  const payload = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...extraHeaders,
  });
  res.end(payload);
}

export default async function handler(req, res) {
  const method = (req.method || 'GET').toUpperCase();
  const cfg = getAppConfig();
  const vercelRegion = process.env.VERCEL_REGION || 'iad1';

  if (method === 'GET') {
    const existingToken = extractRequestToken(req);
    const authenticated = verifyAuthToken(existingToken);
    return sendJson(res, 200, {
      authenticated,
      bareToken: authenticated ? existingToken : null,
      vercelRegion,
      usingCustomEnvPin: isUsingCustomEnvPin(),
      defaults: {
        engine: cfg.defaultEngine || 'scramjet',
        xboxRegion: cfg.defaultXboxRegion || 'EastUS',
        streamBoost1080p: cfg.streamBoost1080p !== false,
      },
    });
  }

  if (method === 'POST') {
    const ip = getClientIp(req);
    const rl = checkLoginRateLimit(ip);
    if (!rl.allowed) {
      return sendJson(
        res,
        429,
        {
          ok: false,
          error: `Too many failed PIN attempts. Try again in ${rl.retryAfterSec}s.`,
        },
        { 'Retry-After': String(rl.retryAfterSec) }
      );
    }

    let body;
    try {
      body = await readJsonBody(req);
    } catch {
      return sendJson(res, 400, { ok: false, error: 'Invalid JSON request body.' });
    }

    const pin = typeof body?.pin === 'string' ? body.pin : '';
    if (!verifyPinConstantTime(pin)) {
      recordFailedLogin(ip);
      return sendJson(res, 401, {
        ok: false,
        error: 'Incorrect access PIN / passcode.',
      });
    }

    clearFailedLogin(ip);
    const days = cfg.sessionDays || 30;
    const token = createAuthToken(days);
    const cookie = buildSessionCookie(req, token, days * 24 * 60 * 60);

    return sendJson(
      res,
      200,
      {
        ok: true,
        bareToken: token,
        vercelRegion,
        defaults: {
          engine: cfg.defaultEngine || 'scramjet',
          xboxRegion: cfg.defaultXboxRegion || 'EastUS',
          streamBoost1080p: cfg.streamBoost1080p !== false,
        },
      },
      { 'Set-Cookie': cookie }
    );
  }

  if (method === 'DELETE') {
    const expiredCookie = buildSessionCookie(req, '', 0);
    return sendJson(
      res,
      200,
      { ok: true, authenticated: false },
      { 'Set-Cookie': expiredCookie }
    );
  }

  return sendJson(res, 405, { error: 'Method Not Allowed' });
}
