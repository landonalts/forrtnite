import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

function copyFiles(srcDir, destDir, files) {
  if (!fs.existsSync(srcDir)) {
    return;
  }
  fs.mkdirSync(destDir, { recursive: true });
  for (const file of files) {
    const from = path.join(srcDir, file);
    const to = path.join(destDir, file);
    if (fs.existsSync(from)) {
      fs.copyFileSync(from, to);
    }
  }
}

copyFiles(
  path.join(root, 'node_modules/@titaniumnetwork-dev/ultraviolet/dist'),
  path.join(root, 'public/vendor/uv'),
  ['uv.bundle.js', 'uv.client.js', 'uv.handler.js', 'uv.sw.js']
);

copyFiles(
  path.join(root, 'node_modules/@mercuryworkshop/scramjet/dist'),
  path.join(root, 'public/vendor/scram'),
  ['scramjet.all.js', 'scramjet.sync.js', 'scramjet.wasm.wasm']
);

copyFiles(
  path.join(root, 'node_modules/@mercuryworkshop/bare-mux/dist'),
  path.join(root, 'public/vendor/baremux'),
  ['index.js', 'index.mjs', 'worker.js']
);

copyFiles(
  path.join(root, 'node_modules/@mercuryworkshop/bare-as-module3/dist'),
  path.join(root, 'public/vendor/baremod'),
  ['index.mjs']
);

console.log('[sync-vendor] Vendor bundles ready in public/vendor/');
